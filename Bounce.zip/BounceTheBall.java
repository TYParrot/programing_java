import java.awt.*;

/** BounceTheBall - 애니메이션 객체를 생성하고 공 운동 시작 */
public class BounceTheBall { 
	public static void main(String[] args) { 
		// 모델 객체 생성 
		int box_size = 200;
		int balls_radius = 6;
		Box box = new Box(box_size);
		BoxWriter boxwriter = new BoxWriter(box);
		// 공을 상자의 적절한 위치에 둠 
		MovingBall ball1 = new MovingBall((int)(box_size / 3.0),
                                         (int)(box_size / 3.0),
                                         balls_radius, box, 3, 2, boxwriter);
		MovingBall ball2 = new MovingBall((int)(box_size / 3.0),
                (int)(box_size / 3.0),
                balls_radius, box, 1, 4, boxwriter);
		BallWriter ball_writer = new BallWriter(ball1, ball2, Color.blue, Color.red);
		BoxWriter box_writer  = new BoxWriter(box);
		AnimationWriter writer = new AnimationWriter(box_writer, ball_writer, box_size);
		// 컨트롤러 객체를 생성하고 애니메이션 시작 
		new BounceController(ball1, ball2, writer).runAnimation();
	}
}

