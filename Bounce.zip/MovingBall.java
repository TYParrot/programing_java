/** MovingBall - 2차원 상자에서 움직이는 공 */
public class MovingBall {
	private int x_pos; // 공의 중심 x 좌표 
	private int y_pos; // 공의 중심 y 좌표 
	private int radius; // 공의 반지름 
	
	private int x_velocity; // 속도 x축 
	private int y_velocity; // 속도 y축 
	
	private int x1_position;
	private int x2_position;
	private int y1_position;
	private int y2_position;
	
	private Box container;
	private BoxWriter containerwriter;
	
	/** Contructor MovingBall - 공 만들기 
	 * @param x_initial - 공의 중심 x 좌표
	 * @param y_initial - 공의 중심 y 좌표
	 * @param r - 공의 반지름 
	 * @param box - 공이 살고 있는 상자 */
	public MovingBall(int x_initial, int y_initial, int r, Box box, int x_vel, int y_vel, BoxWriter writer) {
		x_velocity=x_vel;
		y_velocity=y_vel;
		x_pos = x_initial;
		x_pos = y_initial;
		radius = r;
		container = box;
		containerwriter = writer;
		
	}
	
	/** xPosition - 공의 x축 위치 리턴 */
	public int xPosition() {
		return x_pos;
	}
	
	/** yPosition - 공의 y축 위치 리턴 */
	public int yPosition() {
		return y_pos;
	}
	
	/** radiusOf - 공의 반지름 리턴 */
	public int radiusOf() {
		return radius;
	}
	
	/** move - time_unit 만큼 공을 이동, 벽에 부딪치면 방향을 바꿈
	 * @param time_units - 프레임 사이의 시간 */
	public void move(int time_units, int x1_pos, int x2_pos, int y1_pos, int y2_pos) {
		x1_position=x1_pos;
		x2_position=x2_pos;
		y1_position=y1_pos;
		y2_position=y2_pos;		
		double d =Math.sqrt(Math.pow(x1_position-x2_position,2)+Math.pow(y1_position-y2_position,2));
		
		x_pos = x_pos + x_velocity * time_units;
		if (container.inHorizontalContact(x_pos))
			x_velocity = - x_velocity;
		y_pos = y_pos + y_velocity * time_units;
		if (container.inVerticalContact(y_pos))
			y_velocity = - y_velocity;
		
		if(d<=2.8) {
			x_velocity = - x_velocity;
			y_velocity = - y_velocity;
		}
		
		if(container.inObstacleUp(x1_position, y1_position, containerwriter.offset1, containerwriter.offset2, containerwriter.obstacle_xlength, containerwriter.obstacle_ylength)) { 
			if(y_velocity>0)
				y_velocity = -y_velocity;
	}
		if(container.inObstacleDown(x1_position, y1_position, containerwriter.offset1, containerwriter.offset2, containerwriter.obstacle_xlength, containerwriter.obstacle_ylength)) { 
			if(y_velocity<0)
			y_velocity = -y_velocity;
		}	
	}
}
