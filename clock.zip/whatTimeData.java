import java.time.LocalDateTime;
	
public class whatTimeData {
	private int h;
	
	public int whatS() {
		LocalDateTime now = LocalDateTime.now();
		return 90-now.getSecond()*6;
	}
	
	public int whatM() {
		LocalDateTime now = LocalDateTime.now();
		return 90-now.getMinute()*6;
	}
	
	public int whatH() {
		LocalDateTime now = LocalDateTime.now();
		int minute = now.getMinute();
		h=(90-now.getHour()*30);
		if(minute/12==0) {
			return h;
		}
		else if(minute/12==1) {
			return h-6;
		}
		else if(minute/12==2) {
			return h-12;
		}
		else if(minute/12==3) {
			return h-18;
		}
		else if(minute/12==4){
			return h-24;
		}
		else if(minute/12==5) {
			return h-30;
		}
		else
			return h;

	}
	
	public int whatY() {
		LocalDateTime now = LocalDateTime.now();
		return now.getYear();
		
	}
	
	public int whatMonth() {
		LocalDateTime now = LocalDateTime.now();
		return now.getMonthValue();
		
	}
	
	public int whatD() {
		LocalDateTime now = LocalDateTime.now();
		return now.getDayOfMonth();
		
	}
}
