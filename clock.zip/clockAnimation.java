

public class clockAnimation {
	
	private void delay(int how_long) { 
		try { Thread.sleep(how_long); }
		catch (InterruptedException e) { }
	}
	
	public void runAnimation() {
		
		int paintingdely=20;
		delay(paintingdely);
		clockWriter clock = new clockWriter();
		while(true) {
			clock.repaint();
		}
	}
	
	public static void main(String[] args) {
		clockAnimation run = new clockAnimation();
		run.runAnimation();		
	}
}
