import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.time.*;

public class clockWriter extends JPanel{
	int Width=600;
	int Height=600;

	
	private int hour;
	private int minute;
	private int second;
	private int year;
	private int month;
	private int day;

	
	public clockWriter() {
		JFrame clockwriter= new JFrame();
		clockwriter.getContentPane().add(this);
		clockwriter.setSize(Width, Height);
		clockwriter.setTitle("clock");
		clockwriter.setVisible(true);
		clockwriter.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public void paintComponent(Graphics g) {
		
		whatTimeData data = new whatTimeData();
		hour=data.whatH();
		second=data.whatS();
		minute=data.whatM();
		year=data.whatY();
		month=data.whatM();
		day=data.whatD();
		
		g.setColor(Color.black);
		g.fillRect(0, 0, Width, Height);
		g.setColor(Color.yellow);
		g.fillOval(150, 150, 300, 300);
		LocalDateTime now = LocalDateTime.now();
		int r=130;
		int x=235;
		//초침,분침,시
		g.setColor(Color.blue);
		g.fillArc(x-40, x-40, r+80, r+80, minute, -5);
		g.setColor(Color.orange);
		g.fillArc(x-15, x-15, r+30, r+30, second, -3);
		g.setColor(Color.red);
		g.fillArc(x, x, r, r, hour, -9);
		//눈금 3,6,9,12
		int X1=370;
		int Y1=260;
		g.setColor(Color.pink);
		g.fillArc(X1, Y1, 80, 80, 3, -5);//3
		g.fillArc(X1-110, Y1+110, 80, 80, 273, -5);//6
		g.fillArc(X1-220, Y1, 80, 80, 183, -5);//9
		g.fillArc(X1-110, Y1-110, 80, 80, 93, -5);//12
		//눈금 1,4,7,10
		int X2=325;
		int Y2=163;
		g.setColor(Color.pink);
		g.fillArc(X2, Y2, 60, 60, 63, -5);//1
		g.fillArc(X2+50, Y2+155, 65, 60, 333, -5);//4
		g.fillArc(X2-110, Y2+215, 60, 60, 243, -5);//7
		g.fillArc(X2-165, Y2+60, 60, 60, 153, -5);//10
		//눈금 2,5,8,11
		int X3=375;
		int Y3=210;
		g.setColor(Color.pink);
		g.fillArc(X3, Y3, 60, 60, 33, -5);//2
		g.fillArc(X3-45, Y3+162, 65, 60, 303, -5);//5
		g.fillArc(X3-210, Y3+120, 60, 60, 213, -5);//8
		g.fillArc(X3-175, Y3-40, 60, 60, 123, -5);//11
		//디지털 시계
		DecimalFormat formatter = new DecimalFormat ("00");
		int hour=now.getHour();
		int minute=now.getMinute();
		int second=now.getSecond();
		String time=(formatter.format(hour)+":"+formatter.format(minute)+":"+formatter.format(second));
		g.setColor(Color.yellow);
		g.drawString(time, 10, 30);
		String Year=(year+"."+month+"."+day);
		g.drawString(Year, 520, 550);
	}
	

}
